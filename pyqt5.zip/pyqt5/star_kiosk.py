import sys
import webbrowser
from PyQt5.QtWidgets import *
from PyQt5 import uic
from PyQt5.QtCore import *



form_class = uic.loadUiType("star_kiosk.ui")[0]

class MyWindow(QMainWindow, form_class):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.setWindowTitle('Starbucks')
        self.setGeometry(800, 800, 800, 800)
##복붙시작
        self.Btn_1.clicked.connect(self.Starbucks_open)
        self.dialog = QDialog()

    # 버튼 이벤트 함수
    def Starbucks_open(self):
        # 버튼 추가
        btnDialog = QPushButton("YES", self.dialog)
        btnDialog.move(700, 100)
        # btnDialog.clicked.connect(self.dialog_open)

        btnDialog = QPushButton("NO", self.dialog)
        btnDialog.move(800, 100)
        btnDialog.clicked.connect(self.dialog_close)

        # QDialog 세팅
        self.dialog.setWindowTitle('Starbucks')
        self.dialog.setWindowModality(Qt.ApplicationModal)
        self.dialog.resize(400, 300)
        self.dialog.show()

    # Dialog 닫기 이벤트
    def dialog_close(self):
        self.dialog.close()


## 복붙 끝

        # 버튼에 링크 추가하기
        self.new_btn.clicked.connect(lambda: webbrowser.open('https://www.starbucks.co.kr/whats_new/index.do'))
        self.summer_btn.clicked.connect(lambda: webbrowser.open('https://www.starbucks.co.kr/whats_new/campaign_view.do?pro_seq=1864'))
        self.reward_btn.clicked.connect(lambda: webbrowser.open('https://www.starbucks.co.kr/msr/msreward/level_benefit.do'))






if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = MyWindow()
    myWindow.show()
    app.exec_()